/*jslint browser:true */
/*global createjs */
/*global Box2D */
/*global console */
//*jslint vars: false */
//*jslint unused: false */
var stage;
var FPS = 30;

//region keyCodes
    var KEYCODE_LEFT  = 37;
    //var KEYCODE_UP    = 38;
    var KEYCODE_RIGHT = 39;
    var KEYCODE_DOWN  = 40;
    var KEYCODE_PLUS  = 187;
    var KEYCODE_MINUS = 189;
//endregion

//region gameStates
    function GameState (title) {
        this.title = title;
        this.container = new createjs.Container();
        this.masterEnable  = function() { this.container.visible = true;  this.enable();  };
        this.masterDisable = function() { this.container.visible = false; this.disable(); };
        // should override the following
        this.enable  = function() { };
        this.disable = function() { };
        this.update  = function() {};
    }
    var GameStates = {
        EMPTY : new GameState("empty"),
        Loading : new GameState("loading"),
        StartScreen : new GameState("start"),
        Instructions: new GameState("instructions"),
        Credits: new GameState("credits"),
        Game : new GameState("game"),
        GameOver : new GameState("game over"),
    };
    var CurrentGameState = GameStates.Loading;
    var LastGameState = GameStates.EMPTY;

//endregion

//region Classes
    function Timer() {
        this.gameTimer = 0;
        this.frameCount = 0;
    }
    Timer.prototype.update = function(FPS) {
        this.frameCount = Math.max(0,this.frameCount+1);
        // lets make this only count 1/10s of a second
        if(this.frameCount%(FPS/10) === 0) {
            this.gameTimer = this.frameCount/(FPS);   
        }
    };
    Timer.prototype.reset = function() {
        this.frameCount = 0;
        this.gameTimer = 0;
    };
    Timer.prototype.addSeconds = function(seconds, FPS) {
        this.frameCount += seconds * FPS;
    };
    
    function Coord() {
        return Coord(0,0);
    }
    function Coord(existingCoord) {
        return Coord(existingCoord.x,existingCoord.y);
    }
    function Coord(x,y) {
        this.x = x;
        this.y = y;
    }
    Coord.prototype.toString = function() { return "{"+this.x+","+this.y+"}"; };
    //math
    Coord.prototype.add = function(that)     { return new Coord(this.x+that.x,this.y+that.y); };
    Coord.prototype.sub = function(that)     { return new Coord(this.x-that.x,this.y-that.y); };
    Coord.prototype.mul = function(constent) { return new Coord(constent * this.x,constent * this.y); };
    Coord.prototype.div = function(constent) { return this.mul(1/constent); };
    Coord.prototype.dot = function(that)     { return this.x * that.x + this.y * that.y; };
    Coord.prototype.lengthSquared = function() { return this.dot(this); };
    Coord.prototype.length     = function()    { return Math.sqrt(this.lengthSquared(this)); };
    Coord.prototype.normalized = function()    { return new Coord(this.x,this.y).div(Math.sqrt(this.lengthSquared(this))); };
    Coord.prototype.perpCW     = function()    { return new Coord(-this.y,this.x); };
    Coord.prototype.perpCCW    = function()    { return new Coord(this.y,-this.x); };
    Coord.prototype.LERP       = function(percent, that) { return this.mul(1-percent).add(that.mul(percent)); };
    Coord.prototype.cross      = function(that) { return this.x * that.y - this.y * that.x; };
    Coord.prototype.projection = function(norm) { return (this.dot(norm).mul(norm)).div(norm.lengthSquared()); };
    Coord.prototype.rejection  = function(norm) { return this.sub(this.projection(norm)); };
    Coord.prototype.isZero     = function()     { return this.x === 0 && this.y === 0;};

    //will have to make and manager per scene
    function KeyStateManager(KEYCODE) {
        if(typeof(KEYCODE) === 'string') { KEYCODE = KEYCODE.charCodeAt(0); }
        this.keyCode = KEYCODE;
        this.numOfFramesClicked = 0;
        
        // override me
        this.onClick = function() {};
    }
    KeyStateManager.prototype.update = function() {
        this.numOfFramesClicked = keyStates[this.keyCode] === true ? this.numOfFramesClicked + 1 : 0;
        if(this.isDown()) { this.onClick(); }
    };
    KeyStateManager.prototype.isDown = function() { return this.numOfFramesClicked === 1; };
//endregion

//region functions
    function stackButtons(buttons, padding) {
        var offset = stage.canvas.height - padding;
        buttons.reverse();
        buttons.map(function(item) {
            if(typeof(item) != 'undefined' && typeof item.getBounds === 'function') {
                var pos = {
                    x: stage.canvas.width / 2 - item.getBounds().width / 2,
                    y: offset - item.getBounds().height / 2,
                };

                offset -= item.getBounds().height + padding;
                item.x = pos.x;
                item.y = pos.y;
            }
        });
    }
    function moveAndLoop(object,speed,radius) {
        object.x += speed;
        if(object.x - radius > stage.canvas.width) {
            object.x = -radius;
        }
    }
    function generateRegButton(title) {
        return function(button,onClickMethod) {
            button.gotoAndStop(title+"Up");
            button.on("click", onClickMethod);
            button.on("mouseover", function(evt) { evt = evt; button.gotoAndStop(title+"Over"); });
            button.on("mouseout",  function(evt) { evt = evt; button.gotoAndStop(title+"Up"); });
            button.on("mousedown", function(evt) { evt = evt; button.gotoAndStop(title+"Down"); });
            return button;
        };
    }
    function CreateButtonFromSprite(btnPlay, title, onClickMethod) {
        generateRegButton(title)(btnPlay,onClickMethod);
        return btnPlay;
    }
    //condition is a function(a) reutrns true/false
    function Where(theArray, condition) {
        var ret = [];
        theArray.map(function(item) { if(condition(item)) { ret.push(item); }});
        return ret;
    }
    function Rand(min,max) {
        return Math.round(Math.random() * (max - min) + min);
    }
    function RandomElement(array) {
        return array[Rand(0,array.length-1)];
    }
    function Max(array) {
        var ret = 0;
        array.map(function(item) { if(item > ret) {ret = item;}});
        return ret;
    }
//endregion

//region loading files
var manifest = [
    {src:"title.png", id:"title"},
    {src:"background.png", id:"background"},
    {src:"instructions.png", id:"instructions"},
    {src:"credits.png", id:"credits"},
    {src:"gameover.png", id:"gameover"},
    {src:"buttons.png", id:"button"},
    {src:"SpeakerOn.png", id:"SpeakerOn"},
    {src:"SpeakerOff.png", id:"SpeakerOff"},
    {src:"Barrier.png", id:"Barrier"},
    {src:"sprites.png", id:"mySprites"}
];
var musicManifest = [
    {src:"GameOver.wav", id:"GameOver"},
    {src:"GamePlay.wav", id:"GamePlay"},
    {src:"loading.wav", id:"Loading"},
    {src:"StartScreen.wav", id:"StartScreen"}
];

var queue;

var backgroundMusic = {
    //private
    _enabled: true,
    _src: null,
    //public
    
    //allows audio to play
    enable: function() {
        if(!this._enabled && this._src !== null) {
            this._src.resume();
        }
        this._enabled = true;
    },
    
    //audio will stop
    disable: function() {
        if(this._src!==null) { this._src.pause(); }
        this._enabled = false;
    },
    
    //changes audio, if existing audio is playing, it will be stopped
    //will only play if already enabled
    setSound: function(newGuy) {
        var temp = this._enabled;
        this.disable();
        this._src = newGuy;
        this.disable();
        if(temp) { this.enable(); }
    },
    setSoundFromString: function(audioKey, loop) {
        var willLoop = loop ? {loop:-1} : null;
        var audio = createjs.Sound.play(audioKey,willLoop);
        this.setSound(audio);
    },
    //static functions
    isPaused: function(audio)    { return !audio.paused; },
    toggleMusic: function(audio) {
        return this.isPaused(audio) ? audio.resume() || true : audio.pause() && false;
    },
    
    //stops and sets audio src to null
    removeSound: function() {
        var temp = this._enabled;
        this.disable();
        this._src = null;
        this._enabled = temp;
    },
    
};


function setupMusic() {
    createjs.Sound.alternateExtensions = ["ogg"];
    createjs.Sound.addEventListener("fileload",playSound);
    createjs.Sound.on("complete",function() { backgroundMusic.allLoaded = true; backgroundMusic.enable();});
    createjs.Sound.registerManifest(musicManifest,"assets/audio/");
    function playSound(event) {
        if(event.id == "Loading") {
            backgroundMusic.setSoundFromString(event.src,true);
        }
    }
}
var spriteSheets = {
    buttons: null,
    barrier: null,
    makeButton: function() {
        return (new createjs.Sprite(this.buttons));
    },
    makeBarrier: function() {
        return (new createjs.Sprite(this.barrier));
    },
    mainCharacter: null
};

function loadImage(key) {
    return new createjs.Bitmap(queue.getResult(key));
}

function loadFiles() {
    queue = new createjs.LoadQueue(true, "assets/images/");  //files are stored in 'images' directory
    queue.on("complete", loadComplete, this);  //when loading is done run 'loadComplete()'
    queue.on("progress", handleProgress, this);
    
    var progress = new createjs.Shape(); 
    var progressBellow = new createjs.Shape();
    var txt = new createjs.Text();

    function ShapeData(widthPercent, height) {
        this.width = stage.canvas.width * widthPercent;
        this.height = height;
        this.x = stage.canvas.width / 2 - this.width / 2;
        this.y = stage.canvas.height / 2 - this.height / 2;
    }

    var dims = new ShapeData(50/100,100);

    progress.graphics.beginStroke("#280000").drawRect(dims.x,dims.y,dims.width,dims.height);
    progressBellow.graphics.beginStroke("#280000").drawRect(dims.x,dims.y,dims.width,dims.height);
    txt.x = dims.x+2;
    txt.y = dims.y+(dims.height) / 2 - 9;
    txt.font = ("13px Verdana");
    txt.color = ("#17A");
    
    function handleProgress(event) {
        progress.graphics.clear();
        // Draw the progress bar
        progress.graphics.beginFill("#ccc").drawRect(dims.x,dims.y,dims.width*(event.loaded / event.total),dims.height);
        txt.text = ("Loading " + 100*(event.loaded / event.total) + "%");
        stage.update();
    }
    function loadComplete(event) {
        event = event;
        //once the files are loaded, put them into usable objects
        txt.text = "Click to continue";
        progress.on("click",function() {
            backgroundMusic.setSoundFromString("StartScreen",true);
            initSprites();
            init();
        });
    }
    GameStates.Loading.container.addChild(progress,progressBellow,txt);
    
    queue.loadManifest(manifest);  //load files listed in 'manifest'
}

function initSprites() {
    var buttonSheet = new createjs.SpriteSheet({
        images: [queue.getResult("button")],
        frames: {width: 94, height: 33, regX: 46, regY: 15},
        animations: {
        playUp:   [0, 0, "playUp"],
        playOver: [1, 1, "playOver"],
        playDown: [2, 2, "playDown"],
        instructUp:   [3, 3, "instructUp"],
        instructOver: [4, 4, "instructOver"],
        instructDown: [5, 5, "instructDown"],
        menuUp:   [6, 6, "menuUp"],
        menuOver: [7, 7, "menuOver"],
        menuDown: [8, 8, "menuDown"],
        creditsUp:   [9, 9,   "creditsUp"],
        creditsOver: [10, 10, "creditsOver"],
        creditsDown: [11, 11, "creditsDown"],
        } 
    });
    spriteSheets.buttons = buttonSheet;
    //This takes the images loaded from the sprite sheet and breaks it into the individual frames. I cut and pasted the 'frames' parameter from the .js file created by Flash when I exported in easelJS format. I didn't cut and paste anything except 'frames' because I am using preloadJS to load all the images completely before running the game. That's what the queue.getResult is all about.
	
    spriteSheets.mainCharacter = new createjs.SpriteSheet({
        images: [queue.getResult("mySprites")],
        frames: [[0,0,114,96,0,57.849999999999994,96.55],[114,0,125,95,0,63.849999999999994,95.55],[0,96,130,95,0,66.85,95.55],[130,96,125,94,0,63.849999999999994,94.55],[0,191,114,96,0,57.849999999999994,96.55],[114,191,96,102,0,46.849999999999994,102.55],[0,293,78,105,0,36.849999999999994,105.55],[78,293,95,102,0,46.849999999999994,102.55]],
        animations: {
            fly:   [0, 7, "fly",0.5]
        }     
    });
    
    spriteSheets.barrier = new createjs.SpriteSheet({
        images: [queue.getResult("Barrier")],
        frames: [[0,0,185,184,0,-4.4,6.7],[185,0,185,184,0,-4.4,6.7],[0,184,185,184,0,-4.4,6.7],[185,184,185,184,0,-4.4,6.7]],
        animations: {
            pulse:   [0, 3, "pulse",0.5]
        }     
    });
    
    
    spriteSheets.mainCharacter.paused = false;
}

//endregion

//region init
    //region global assets (mouse and keys)
        var mouse = {
            pos: new Coord(),
        };
        function mouseInit() {
            stage.enableMouseOver();
            stage.on("stagemousemove", function(evt) {
                mouse.pos.x = Math.floor(evt.stageX);
                mouse.pos.y = Math.floor(evt.stageY);
            });
        }
        //universial across all scenes
        var keyStates = [];
        function handleKeyDown(evt) {
            if(!CurrentGameState) { return; }
            if(!evt){ evt = window.event; }  //browser compatibility
            keyStates[evt.keyCode] = true;
            //console.log(evt.keyCode+"up");
        }
        function handleKeyUp(evt) {
            if(!CurrentGameState) { return; }
            if(!evt){ evt = window.event; }  //browser compatibility
            keyStates[evt.keyCode] = false;
            //console.log(evt.keyCode+"down");
        }
        document.onkeydown = handleKeyDown;
        document.onkeyup = handleKeyUp;
    //endregion
    
    function setupCanvas() {
        var canvas = document.getElementById("game");
        canvas.width = 800;
        canvas.height = 600;
        stage = new createjs.Stage(canvas);
    }

    function registerGameLoop() {
        function loop() {
            if(CurrentGameState != LastGameState) {
                LastGameState.masterDisable();
                CurrentGameState.masterEnable();
            }
            LastGameState = CurrentGameState;
            CurrentGameState.update();
            stage.update();
        }
        createjs.Ticker.addEventListener("tick", loop);
        createjs.Ticker.setFPS(FPS);
    }
    
    function main() {
        setupCanvas();
        mouseInit();
        setupMusic();
        initLoadingScreen();
        registerGameLoop();

        loadFiles();
    }
    
    if (!!(window.addEventListener)) {
        window.addEventListener("DOMContentLoaded", main);
    } else { // if IE
        window.attachEvent("onload", main);
    }
//endregion

var score = 0;

//to be called after files have been loaded
function init() {
    GameStates.StartScreen.container.addChild(  loadImage("title")        );
    GameStates.Game.container.addChild(         loadImage("background")   );
    GameStates.Instructions.container.addChild( loadImage("instructions") );
    GameStates.Credits.container.addChild(      loadImage("credits") );
    GameStates.GameOver.container.addChild(     loadImage("gameover")     );
    stage.addChild(GameStates.EMPTY.container);         GameStates.EMPTY.masterDisable();
    stage.addChild(GameStates.StartScreen.container);   GameStates.StartScreen.masterDisable();
    stage.addChild(GameStates.Instructions.container);  GameStates.Instructions.masterDisable();
    stage.addChild(GameStates.Credits.container);       GameStates.Credits.masterDisable();
    stage.addChild(GameStates.Game.container);          GameStates.Game.masterDisable();
    stage.addChild(GameStates.GameOver.container);      GameStates.GameOver.masterDisable();
    
    //adding speaker
    var speaker = {
        onImg: loadImage("SpeakerOn"),
        offImg: loadImage("SpeakerOff"),
    };
    speaker.onImg.x = stage.canvas.width  - speaker.onImg.getBounds().width;
    speaker.onImg.y = stage.canvas.height - speaker.onImg.getBounds().height;
    speaker.offImg.x = speaker.onImg.x;
    speaker.offImg.y = speaker.onImg.y;
    speaker.onImg.on("click", function() {
        speaker.onImg.visible  = false;
        speaker.offImg.visible = true;
        backgroundMusic.disable();
    });
    speaker.offImg.on("click", function() {
        speaker.offImg.visible = false;
        speaker.onImg.visible  = true;
        backgroundMusic.enable();
    });
    speaker.offImg.visible = false;
    stage.addChild(speaker.onImg);
    stage.addChild(speaker.offImg);
    
    
    //init start
    {
        var BTN = [];
        BTN.push(CreateButtonFromSprite(spriteSheets.makeButton(),"play",    function() { CurrentGameState = GameStates.Game;         }));
        BTN.push(CreateButtonFromSprite(spriteSheets.makeButton(),"instruct",function() { CurrentGameState = GameStates.Instructions; }));
        BTN.push(CreateButtonFromSprite(spriteSheets.makeButton(),"credits", function() { CurrentGameState = GameStates.Credits;      }));
        
        stackButtons(BTN,10);
        
        BTN.map(function(item) {
            GameStates.StartScreen.container.addChild(item);
        });
    }
    var PADDING = 5;
    //init instructions
    {
        var BTN_mainMenu = spriteSheets.makeButton();
        CreateButtonFromSprite(BTN_mainMenu,"menu",function() { CurrentGameState = GameStates.StartScreen; });
        BTN_mainMenu.x = stage.canvas.width - BTN_mainMenu.getBounds().width - PADDING;
        BTN_mainMenu.y = stage.canvas.height - BTN_mainMenu.getBounds().height - PADDING;
        GameStates.Instructions.container.addChild(BTN_mainMenu);
        
    }
    //init credits
    {
        var BTN_mainMenu_creditsScreen = CreateButtonFromSprite(spriteSheets.makeButton(),"menu",function() { CurrentGameState = GameStates.StartScreen; });
        BTN_mainMenu_creditsScreen.x = stage.canvas.width - BTN_mainMenu_creditsScreen.getBounds().width - PADDING;
        BTN_mainMenu_creditsScreen.y = stage.canvas.height - BTN_mainMenu_creditsScreen.getBounds().height - PADDING;
        GameStates.Credits.container.addChild(BTN_mainMenu_creditsScreen);
        
    }
    //init game
    initGameScene(GameStates.Game.container);
    //init gameOver
    {
        var finalScore = new createjs.Text("Score:\n"+score, "50px Arial", "#000");
        finalScore.x = stage.canvas.width / 2 - 50;
        finalScore.y = stage.canvas.height / 2;
        GameStates.GameOver.container.addChild(finalScore);
        
        var btn = spriteSheets.makeButton();
        CreateButtonFromSprite(btn,"menu",function() { CurrentGameState = GameStates.StartScreen; });
        
        GameStates.GameOver.container.addChild(btn);
        GameStates.GameOver.enable = function() {
            backgroundMusic.setSoundFromString("StartScreen",true);
            createjs.Sound.play("GameOver");
        };
        var btns = [btn];
        stackButtons(btns,10);
        GameStates.GameOver.update = function() {
            finalScore.text = "Score:\n"+score;
        };
    }
    CurrentGameState = GameStates.StartScreen;
}
//progress bar will run anything listed here should only be animation stuff without using any images
function initLoadingScreen() {
    var circle = new createjs.Shape();
    circle.graphics.beginFill("#A66").drawCircle(0, 0, 40);  //creates circle at 0,0, with radius of 40
    circle.x = circle.y = 100;  //this just sets the x and y equal to 50
    GameStates.Loading.container.addChild(circle);  //add the circle to the stage but it is not apparent until the stage is updated
        
    GameStates.Loading.update = function() {
        moveAndLoop(circle,2,40);
    };
    stage.addChild(GameStates.Loading.container);
    CurrentGameState = GameStates.Loading;
}

//le game
var player;
function initGameScene(container) {
    var everCheated = false;
    var cheatEnabled = false;
    var cheatCode = new KeyStateManager("J");
    cheatCode.onClick = function() {cheatEnabled = cheatEnabled ? false : true;};
    var myKeys = [cheatCode];
    
    //objects
    var bars = [];
    //var player;
    
    //constents
    var playerBoost = new Coord(0,-4);
    var playerSize = new Coord(50,50);
    var holeWidth = playerSize.x * 1.5;
    var holePossibilities = [1,1,1,1,1,1,
                             2,2,2,2,2,2,2,2,
                             3,3,3,3,3,
                             4,4,
                            ]; // add to this array to change probibilites
    
    //stuff that decrements 
    var speed = new Coord();
    var acc   = new Coord();
    
    var barHeight;
    var heightDecreseSpeed;
    
    //misc varables
    var lastBar;
    
    var diffFromMaxSpeed = 0;
    var maxDiff = 0;
    
    //classes
    function GameObject(image,scale) {
        this.view = image;
        this.pos = new Coord();
        this.scale = scale || new Coord(1,1);
        this.getMin = function()   { return this.pos; };
                             // HIPPO
        this.getMax = function()   {
            var offset = new Coord(this.view.getBounds().width,this.view.getBounds().height);
             offset.x *= this.scale.x;
             offset.y *= this.scale.y;
            return this.pos.add(offset);
        };
        this.getDims   = function() { return this.getMax().sub(this.getMin()); };
        this.getWidth  = function() { return this.getDims().x; };
        this.getHeight = function() { return this.getDims().y; };
        this.isAlive = true;
    }
    GameObject.prototype.update = function() {
        this.view.x = this.pos.x;
        this.view.y = this.pos.y;
        this.view.scaleX = this.scale.x;
        this.view.scaleY = this.scale.y;
    };
    GameObject.prototype.moveMeCollision = function(that) {
        
        if(this.getMax().x >= that.getMin().x &&
           this.getMin().x <= that.getMax().x &&
           this.getMax().y >= that.getMin().y &&
           this.getMin().y <= that.getMax().y)
        {
            var minDiff = this.getMin().sub(that.getMin());
            var maxDiff = this.getMax().sub(that.getMin());
            if(minDiff.x < 0) { // left side
                this.pos.x += -maxDiff.x;
            } else if(maxDiff.x > that.getWidth()) { // right side
                var diff = that.getMax().sub(this.getMin()).x;
                this.pos.x += diff;
            } else { // top collision
                this.pos.y += -maxDiff.y;
            }
        }
    };
    
    //game functions
    function getInactiveBars() {
        return Where(bars,function(item) {
            return !item.isAlive;
        });
    }
    function RawBarMaker(width, height, pos) {
        /* HIPPO
        var shape = new createjs.Shape();
        shape.graphics.beginFill("#000").drawRect(0,0,width,height);
        shape.setBounds(0,0,width,height);
        //*/
        //*
        var shape = spriteSheets.makeBarrier();
        shape.gotoAndPlay("pulse");
        //*/
        container.addChild(shape);
        return BarMaker(shape,width,height,pos);
    }
    function BarMaker(view, width, height, pos) {
        var ret = new GameObject(view);
        ret.scale = new Coord();
        ret.scale.x = width  / view.getBounds().width;
        ret.scale.y = height / view.getBounds().height;
        ret.pos = pos;
        lastBar = ret;
        return ret;
    }
    //will rescale the bar
    function resuseBar(gameObj,width,pos) {
        var height = 20;
        gameObj.scale.x = width  / gameObj.view.getBounds().width;
        gameObj.scale.y = height / gameObj.view.getBounds().height;
        gameObj.pos = pos;
        lastBar = gameObj;
        gameObj.isAlive = true;
    }
    function spawnBarRowAt(height, pool) {
        var numOfHoles = RandomElement(holePossibilities);
        var chunkRange = stage.canvas.width / numOfHoles;
        var lastEndPos = new Coord(-0.01,height);
        pool = pool || getInactiveBars();
        for(var i=0;i<numOfHoles;i++) {
            //get a random hole position in the chunk range
            var startX = i * chunkRange;
            var endX = startX + chunkRange-holeWidth;
            var pos = new Coord(Rand(startX,endX),height);
            
            var barWidth = Math.abs(lastEndPos.sub(pos).x);
            
            resuseBar(pool[i],barWidth,lastEndPos);
            
            lastEndPos = pos.add(new Coord(holeWidth,0));
            
        }
        var barwidth = Math.abs(lastEndPos.sub(new Coord(stage.canvas.width,height)).x);
        resuseBar(pool[numOfHoles],barwidth,lastEndPos);
    }
    function spawnRow(pool) {
        var lastY = lastBar.getMax().y;
        var thisHeight = lastY + barHeight;
        spawnBarRowAt(thisHeight,pool);
        barHeight -= heightDecreseSpeed;
        barHeight = Math.max(barHeight,playerSize.y*1.5);
    }
    function avalableRowsToSpawn(pool) {
        pool = pool || getInactiveBars();
        return Math.floor(pool.length / (Max(holePossibilities) + 1));
    }
    

    var MaxSpeedBar = null;
    GameStates.Game.update = function() {
        //region updating keys
        everCheated = everCheated || cheatEnabled;
        /*jshint -W069 */
        myKeys.map(function(item) {item.update();}); // update each key
        if(keyStates[KEYCODE_LEFT]  || keyStates[65])  { player.pos.x -= Math.max(24,-2*speed.y); }
        if(keyStates[KEYCODE_RIGHT] || keyStates[68]) { player.pos.x += Math.max(24,-2*speed.y); }
        //if(keyStates[KEYCODE_UP])    { player.pos.y -= -2*speed.y; }
        if(everCheated  && keyStates[KEYCODE_DOWN])  { player.pos.y += Math.min(24,-speed.y); }
        //endregion
        maxDiff = Math.max(maxDiff,diffFromMaxSpeed);
        //update hud
        {
            if(diffFromMaxSpeed > 0) {
                descriptionText.text = "Score:"+score+"\nApproaching Max Speed";
                MaxSpeedBar.scaleX = diffFromMaxSpeed / maxDiff;
                MaxSpeedBar.visible = true;
            } else {
                descriptionText.text = "Score:"+score+"\nMax Speed!";
                MaxSpeedBar.visible = false;
            }
        }
        
        //spawning new rows
        {
            var pool = getInactiveBars();
            var numOfSupportedRows = avalableRowsToSpawn(pool);
            for(i=0;i<numOfSupportedRows;i++) {
                spawnRow();
            }
        }
        
        player.pos = player.pos.add(speed.mul(-1).add(playerBoost));
        // collision with floor
        {
            //floor
            var diffFromFloor = player.getMax().sub(new Coord(0,stage.canvas.height));
            if(diffFromFloor.y > 0) { player.pos.y -= diffFromFloor.y; }
            //game over
            if(player.getMax().y < 0) {
                CurrentGameState = GameStates.GameOver;
            }
            //walls
            var diffLeft = player.getMax().sub(new Coord(stage.canvas.width,0));
            if(diffLeft.x > 0) { player.pos.x += -diffLeft.x; }
            if(player.getMin().x < 0) { player.pos.x = 0; }
        }
        if(!cheatEnabled) {
            speed = speed.add(acc);
            acc = acc.mul(0.9999);
            diffFromMaxSpeed = speed.y + 20/1.7;
            speed.y = Math.max(-20/1.7,speed.y);
            score += 1;
            //* for better accuracy
            for(var i=0;i<bars.length;i++) {
                //update physics
                player.moveMeCollision(bars[i]);
            }
            //*/

            for(i=0;i<bars.length;i++) {
                if(bars[i].isAlive) {
                    //update bars
                    bars[i].pos = bars[i].pos.add(speed);
                    //update physics
                    player.moveMeCollision(bars[i]);
                    //update graphics
                    bars[i].update();
                    bars[i].isAlive = (bars[i].getMax().y > 0);
                }
                bars[i].view.visible = bars[i].isAlive;
            }
        }
        player.update();
    };
    GameStates.Game.enable = function() {
        backgroundMusic.setSoundFromString("GamePlay",true);
        bars.map(function(item) {item.isAlive = false;});

        
        spawnBarRowAt(stage.canvas.width/2);
        
        player.pos.x = stage.canvas.width / 2 - player.scale.x / 2;
        player.pos.y = 30;
        
        speed = new Coord(0,-1);
        acc   = new Coord(0,-0.01);
        playerBoost = new Coord(0,4);
        barHeight = 200;
        heightDecreseSpeed = 1;
        
        score = -(speed.y).toString();
        
        theGuy.gotoAndPlay("fly");
        theGuy.x = 0;
        theGuy.y = stage.canvas.height / 2 - theGuy.getBounds().height / 2;
    };
    
    
    var maxPossibleRowsOnScreen = function() {
        var maxBarDistance = playerSize.y * 1.5;
        var maxRows = stage.canvas.height / maxBarDistance + 1;
        return maxRows * Max(holePossibilities);
    }();
    for(var i=0;i<maxPossibleRowsOnScreen;i++) {
        var toAdd = RawBarMaker(1,1,new Coord(0,0));
        toAdd.isAlive = false;
        bars.push(toAdd);
    }
    
    
    
    var descriptionText = new createjs.Text("[placeholder]", "25px Arial", "#FFF");
    descriptionText.x = 5;
    descriptionText.y = 5;
    container.addChild(descriptionText);
    
    MaxSpeedBar = new createjs.Shape();  //creates object to hold a shape
    MaxSpeedBar.graphics.beginFill("#A66").drawRect(0, 0, stage.canvas.width/2,40); 
    MaxSpeedBar.x = 0;
    MaxSpeedBar.y = 60;
    container.addChild(MaxSpeedBar);
    
    var theGuy = new createjs.Sprite(spriteSheets.mainCharacter);
    container.addChild(theGuy);
    player = new GameObject(theGuy,new Coord(20,20));
    player.scale = new Coord();
    player.scale.x = 50  / theGuy.getBounds().width;
    player.scale.y = 50 / theGuy.getBounds().height;
    player.getMin = function()   {
        return player.pos;
    };
    player.getMax = function()   {
        var offset = new Coord(player.view.getBounds().width,0);
         offset.x *= this.scale.x / 2;
        return this.pos.sub(offset);
    };

}


/* requirements


Minimum Requirements:
    Use CreateJS and no other frameworks or libraries except Box2D, jQuery, and/or the advanced collision detection found here: http://indiegamr.com/easeljs-pixel-perfect-collision-detection-for-bitmaps-with-alpha-threshold/
    Use the game template developed for the last assignment
    There should be some type of scoring system
-   Have at least one graphical representation of a game variable (i.e. timer bar, health bar, progress bar)
    At least two sound effects
    Have the 'J' key be a toggle that makes the game much easier to play
    Do not use any graphics or sound you are not legally allowed to use
    List yourself in a credits section as the designer/developer of the game

Additional Requirements:
    Solid UX/UI
    Focus on solid game play
    Make sure the game is well-balanced and not too easy or too hard
    The game should require some level of skill but also a little element of random luck as well
    Don't worry about finished graphics, use simple shapes as place holders
    Nothing should be broken and I should not be able to break anything
//*/